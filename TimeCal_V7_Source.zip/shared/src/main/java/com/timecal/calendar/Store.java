package com.timecal.calendar;
import android.content.*;
import android.util.Log;
import com.google.android.gms.wearable.*;
import org.json.*;
import java.util.*;
import java.time.*;
import java.nio.charset.StandardCharsets;
final class Store {
    static final String PREFIX="/timecal/task/";
    static final String PREF="timecal_tasks";
    static class Entry {
        String id,title,date,time,kind,writer; String repeat="none", parent=""; boolean reminder=false; int lead=0, leads=1; long rev; boolean done,deleted;
        Entry(String id,String title,String date,String time,String kind,boolean done,boolean deleted,long rev,String writer){this.id=id;this.title=title;this.date=date;this.time=time;this.kind=kind;this.done=done;this.deleted=deleted;this.rev=rev;this.writer=writer;}
        String json(){try{return new JSONObject().put("id",id).put("title",title).put("date",date).put("time",time).put("kind",kind).put("done",done).put("deleted",deleted).put("rev",rev).put("writer",writer).put("repeat",repeat).put("parent",parent).put("reminder",reminder).put("lead",lead).put("leads",leads).toString();}catch(JSONException e){throw new IllegalStateException(e);}}
        static Entry parse(String s){try{JSONObject j=new JSONObject(s);String id=j.getString("id"),date=j.getString("date"),time=j.getString("time");UUID.fromString(id);LocalDate.parse(date);LocalTime.parse(time);Entry e=new Entry(id,j.getString("title"),date,time,j.optString("kind","任务"),j.optBoolean("done"),j.optBoolean("deleted"),j.getLong("rev"),j.getString("writer")); e.repeat=Repeat.KEYS[Repeat.index(j.optString("repeat","none"))]; e.parent=j.optString("parent",""); if(!e.parent.isEmpty())UUID.fromString(e.parent); e.reminder=j.optBoolean("reminder",false); e.lead=Math.max(0,Math.min(10080,j.optInt("lead",0))); e.leads=LeadTimes.normalize(j.optInt("leads",LeadTimes.single(e.lead))); return e;}catch(Exception e){return null;}}
    }
    final Context ctx; final SharedPreferences p,meta;
    Store(Context c){ctx=c.getApplicationContext();p=ctx.getSharedPreferences(PREF,0);meta=ctx.getSharedPreferences("timecal_meta",0);}
    List<Entry> all(){List<Entry> r=new ArrayList<>();for(Object v:p.getAll().values()){if(v instanceof String){Entry e=Entry.parse((String)v);if(e!=null)r.add(e);}}return r;}
    List<Entry> day(LocalDate d){return day(d,all());}
    List<Entry> day(LocalDate d,List<Entry> snapshot){
        List<Entry> r=new ArrayList<>(); Map<String,Entry> records=new HashMap<>(); for(Entry e:snapshot)records.put(e.id,e);
        for(Entry e:snapshot)if(!e.deleted&&e.parent.isEmpty()&&!HolidayReminders.isConfig(e)&&Repeat.matches(LocalDate.parse(e.date),d,e.repeat)){
            if(e.repeat.equals("none")){r.add(e);continue;}
            String id=UUID.nameUUIDFromBytes((e.id+"/"+d).getBytes(StandardCharsets.UTF_8)).toString(); Entry saved=records.get(id);
            Entry occ=new Entry(id,e.title,d.toString(),e.time,e.kind,saved!=null&&!saved.deleted&&saved.done,false,0,""); occ.parent=e.id;occ.repeat=e.repeat;occ.reminder=e.reminder;occ.lead=e.lead;occ.leads=e.leads;r.add(occ);
        }
        r.sort(Comparator.comparing((Entry e)->e.time).thenComparing(e->e.id));return r;
    }
    Entry template(Entry e){return get(e.parent.isEmpty()?e.id:e.parent);}
    void toggle(Entry e){synchronized(Store.class){for(Entry current:day(LocalDate.parse(e.date)))if(current.id.equals(e.id)){current.done=!current.done;change(current);return;}}}
    synchronized String writer(){String v=meta.getString("writer",null);if(v==null){v=UUID.randomUUID().toString();meta.edit().putString("writer",v).commit();}return v;}
    Entry get(String id){return Entry.parse(p.getString(id,""));}
    static boolean newer(Entry a,Entry b){return b==null||a.rev>b.rev||(a.rev==b.rev&&a.writer.compareTo(b.writer)>0);}
    void merge(Entry e){if(e==null)return;boolean changed=false;synchronized(Store.class){if(newer(e,get(e.id))){p.edit().putString(e.id,e.json()).commit();changed=true;}}if(changed)Reminders.schedule(ctx);}
    void change(Entry e){synchronized(Store.class){Entry old=get(e.id);e.rev=Math.max(System.currentTimeMillis(),old==null?1:old.rev+1);e.writer=writer();p.edit().putString(e.id,e.json()).commit();meta.edit().putString("pending_"+e.id,e.json()).commit();}send(e);Reminders.schedule(ctx);}
    void send(Entry e){try{PutDataMapRequest map=PutDataMapRequest.create(PREFIX+e.id);map.getDataMap().putString("record",e.json());Wearable.getDataClient(ctx).putDataItem(map.asPutDataRequest().setUrgent()).addOnSuccessListener(x->{synchronized(Store.class){if(e.json().equals(meta.getString("pending_"+e.id,"")))meta.edit().remove("pending_"+e.id).apply();}}).addOnFailureListener(x->Log.w("TimeCal","Sync queued",x));}catch(Exception x){Log.w("TimeCal","Wear unavailable",x);}}
    void receive(DataItem item){if(!item.getUri().getPath().startsWith(PREFIX))return;try{Entry e=Entry.parse(DataMapItem.fromDataItem(item).getDataMap().getString("record"));if(e!=null&&item.getUri().getPath().equals(PREFIX+e.id))merge(e);}catch(Exception x){Log.w("TimeCal","Bad record",x);}}
    void refresh(){try{Wearable.getDataClient(ctx).getDataItems().addOnSuccessListener(items->{try{for(DataItem item:items)receive(item);}finally{items.release();}}).addOnFailureListener(e->Log.w("TimeCal","Read sync failed",e));}catch(Exception x){Log.w("TimeCal","Wear unavailable",x);}for(Map.Entry<String,?> v:meta.getAll().entrySet())if(v.getKey().startsWith("pending_")){Entry e=Entry.parse((String)v.getValue());if(e!=null){Entry latest=get(e.id);if(latest!=null&&newer(latest,e))meta.edit().remove(v.getKey()).apply();else send(e);}}}
}
