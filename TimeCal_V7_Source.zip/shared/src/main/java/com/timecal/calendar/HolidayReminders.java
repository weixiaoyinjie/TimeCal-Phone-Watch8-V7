package com.timecal.calendar;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
final class HolidayReminders {
    static String id(String key){return UUID.nameUUIDFromBytes(("timecal/holiday/"+key).getBytes(StandardCharsets.UTF_8)).toString();}
    static final String CN=id("CN"),AR=id("AR"),RECURRING=id("RECURRING");
    static boolean isConfig(Store.Entry e){return CN.equals(e.id)||AR.equals(e.id)||RECURRING.equals(e.id);}
    static Store.Entry config(Store s,String country){Store.Entry e=s.get(id(country));if(e!=null)return e;e=new Store.Entry(id(country),country,"2000-01-01","09:00","__holiday_config",false,false,0,"");e.leads=LeadTimes.single(0)|LeadTimes.single(4320)|LeadTimes.single(10080);e.reminder=country.equals("RECURRING");return e;}
    static boolean enabled(Store.Entry e){return e!=null&&!e.deleted&&e.reminder;}
    static void append(List<Store.Entry> result,LocalDate day,Store.Entry config,String country){
        if(!enabled(config))return;
        String name=country.equals("CN")?Holidays.china(day):Holidays.argentina(day);
        if(name.isEmpty())return;
        String kind=country.equals("CN")?"中国节日":"阿根廷节日";
        Store.Entry e=new Store.Entry(id(country+"/"+day),name,day.toString(),config.time,kind,false,false,0,"");e.reminder=true;e.leads=config.leads;e.lead=config.lead;result.add(e);
    }
}
