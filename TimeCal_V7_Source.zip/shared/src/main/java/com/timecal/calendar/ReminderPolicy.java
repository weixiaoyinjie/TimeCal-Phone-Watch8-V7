package com.timecal.calendar;
final class ReminderPolicy {
    static boolean shared(String kind,String repeat){return !"none".equals(repeat)||"生日".equals(kind)||"节日任务".equals(kind);}
    static boolean shared(Store.Entry e){return shared(e.kind,e.repeat);}
    static boolean enabled(Store.Entry e,Store.Entry recurring){return e.reminder&&(!shared(e)||HolidayReminders.enabled(recurring));}
    static int mask(Store.Entry e,Store.Entry recurring){return shared(e)?recurring.leads:e.leads;}
}
