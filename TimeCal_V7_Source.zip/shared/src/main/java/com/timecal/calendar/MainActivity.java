package com.timecal.calendar;

import android.app.*;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.os.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int WHITE=0xfff4f4f4, GRAY=0xff9e9e9e, GREEN=0xff77ed95, RED=0xffff6565, BLUE=0xff56c0ff, PURPLE=0xffda9bff, YELLOW=0xffffd54f;
    static final int LUNAR_GOLD=0xffffd52b, LUNAR_DIM=0xffad8940, NAV_GREEN=0xff26ed62;
    static String fullLunar(LocalDate d){return Holidays.lunarText(d,true).replace("正月","一月").replace("冬月","十一月").replace("腊月","十二月");}
    Store store; boolean watch,detail=false; LocalDate selected=LocalDate.now(); YearMonth month=YearMonth.from(selected); LinearLayout root, agenda; CalendarView cal; boolean active=false; final Handler handler=new Handler(Looper.getMainLooper());
    final android.content.SharedPreferences.OnSharedPreferenceChangeListener listener=(p,k)->handler.post(()->{if(active)update();});
    @Override public void onCreate(Bundle b){super.onCreate(b);watch=getPackageManager().hasSystemFeature("android.hardware.type.watch");store=new Store(this);HolidayUpdates.init(this);if(b!=null){try{selected=LocalDate.parse(b.getString("date"));month=YearMonth.parse(b.getString("month"));detail=b.getBoolean("detail");}catch(Exception ignored){}}getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);if(watch)getWindow().setFlags(1024,1024);Reminders.channel(this);openNotification(getIntent());render();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("date",selected.toString());b.putString("month",month.toString());b.putBoolean("detail",detail);}
    @Override protected void onStart(){super.onStart();active=true;store.p.registerOnSharedPreferenceChangeListener(listener);store.refresh();update();refreshHolidays(false);}
    @Override protected void onResume(){super.onResume();Reminders.schedule(this);if(active)update();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);openNotification(i);render();}
    void openNotification(Intent i){String d=i.getStringExtra("open_date");if(d!=null){try{selected=LocalDate.parse(d);month=YearMonth.from(selected);detail=true;}catch(Exception ignored){}i.removeExtra("open_date");}}
    void reminderSettings(){Reminders.channel(this);String status="通知："+(Reminders.allowed(this)?"已开启":"未开启")+"\n精确提醒："+(Reminders.exact(this)?"已允许":"未允许，可能延迟")+"\n声音及振动请检查系统通知频道设置。";new AlertDialog.Builder(this).setTitle("提醒权限").setMessage(status).setPositiveButton("通知设置",(d,w)->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},5);else startActivity(new Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(android.provider.Settings.EXTRA_CHANNEL_ID,Reminders.CHANNEL));}).setNeutralButton("精确提醒",(d,w)->{if(Build.VERSION.SDK_INT>=31&&!Reminders.exact(this)){try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName())));}catch(Exception ex){Toast.makeText(this,"请在系统设置中允许闹钟和提醒",Toast.LENGTH_LONG).show();}}else Toast.makeText(this,"精确提醒已允许",Toast.LENGTH_SHORT).show();}).setNegativeButton("关闭",null).show();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);Reminders.schedule(this);}
    @Override protected void onStop(){active=false;store.p.unregisterOnSharedPreferenceChangeListener(listener);super.onStop();}
    int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);b.setOnClickListener(v->r.run());return b;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    void render(){root=column();root.setBackgroundColor(Color.BLACK);cal=null;agenda=null;setContentView(root);
        if(watch&&!detail){cal=new CalendarView();root.addView(cal,new LinearLayout.LayoutParams(-1,-1));return;}
        if(detail){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));agenda=column();agenda.setPadding(dp(watch?20:10),dp(watch?24:10),dp(watch?20:10),dp(watch?32:12));scroll.addView(agenda);populate();return;}
        root.setPadding(dp(8),dp(8),dp(8),0);cal=new CalendarView();root.addView(cal,new LinearLayout.LayoutParams(-1,0,1.25f));
        LinearLayout actions=new LinearLayout(this);actions.addView(button("今天",()->today()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("＋ 添加任务 / 行程",()->edit(null)),new LinearLayout.LayoutParams(0,dp(48),2));actions.addView(button("同步",()->{store.refresh();Toast.makeText(this,"已请求同步",Toast.LENGTH_SHORT).show();}),new LinearLayout.LayoutParams(0,dp(48),1));root.addView(actions);
        ScrollView sc=new ScrollView(this);root.addView(sc,new LinearLayout.LayoutParams(-1,0,0.65f));agenda=column();agenda.setPadding(dp(8),0,dp(8),dp(12));sc.addView(agenda);populate();
    }
    void refreshHolidays(boolean force){int y=month.getYear();Runnable done=()->{Reminders.schedule(getApplicationContext());if(active)update();};HolidayUpdates.refresh(y,force,done);LocalDate now=LocalDate.now();if(now.plusDays(9).getYear()!=now.getYear()&&y!=now.plusDays(9).getYear())HolidayUpdates.refresh(now.plusDays(9).getYear(),false,done);}
    void holidaySettings(){new AlertDialog.Builder(this).setTitle(month.getYear()+" 年节日更新").setMessage(HolidayUpdates.status(month.getYear())+"\n中国 Timor / 阿根廷 ArgentinaDatos。打开日历后每天检查一次；失败保留缓存。仅查询年度节日，不上传任务。数据来自第三方，临时假日可能滞后。").setPositiveButton("立即更新",(d,w)->{refreshHolidays(true);Toast.makeText(this,"正在更新节日，可稍后查看状态",Toast.LENGTH_SHORT).show();}).setNegativeButton("关闭",null).show();}
    void update(){if(cal!=null)cal.refreshPage();if(agenda!=null)populate();}
    void today(){selected=LocalDate.now();month=YearMonth.from(selected);detail=false;if(watch&&cal!=null)update();else render();refreshHolidays(false);}
    void move(int delta){YearMonth m=month.plusMonths(delta);if(m.getYear()<1901||m.getYear()>2099)return;selected=selectionFor(m);month=m;update();refreshHolidays(false);}
    LocalDate selectionFor(YearMonth m){LocalDate now=LocalDate.now();return m.equals(YearMonth.from(now))?now:m.atDay(Math.min(selected.getDayOfMonth(),m.lengthOfMonth()));}
    void select(LocalDate d){selected=d;month=YearMonth.from(d);if(watch){detail=true;render();}else update();refreshHolidays(false);}
    void openSelected(){detail=true;render();}
    @Override public void onBackPressed(){if(detail){detail=false;render();}else super.onBackPressed();}
    void populate(){agenda.removeAllViews();TextView heading=label("",watch?16:20,GREEN);String solar=selected.toString()+"  ";android.text.SpannableString title=new android.text.SpannableString(solar+fullLunar(selected));title.setSpan(new android.text.style.ForegroundColorSpan(LUNAR_GOLD),solar.length(),title.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);title.setSpan(new android.text.style.StyleSpan(Typeface.BOLD),solar.length(),title.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);heading.setText(title);heading.setGravity(Gravity.CENTER);agenda.addView(heading);
        String cn=Holidays.china(selected),ar=Holidays.argentina(selected);if(!cn.isEmpty()){TextView t=label(cn,watch?14:16,RED);t.setGravity(Gravity.CENTER);agenda.addView(t);}if(!ar.isEmpty()){TextView t=label(ar,watch?14:16,BLUE);t.setGravity(Gravity.CENTER);agenda.addView(t);}
        Store.Entry recurring=HolidayReminders.config(store,"RECURRING");java.util.List<Store.Entry> list=store.day(selected);long done=0;for(Store.Entry e:list)if(e.done)done++;TextView count=label(list.isEmpty()?"当天没有任务": "已完成 "+done+" / "+list.size(),watch?13:14,GRAY);count.setGravity(Gravity.CENTER);agenda.addView(count,new LinearLayout.LayoutParams(-1,dp(35)));
        for(Store.Entry e:list){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(3),dp(4),dp(3));row.setBackgroundColor(0xff151515);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));agenda.addView(row,lp);CheckBox cb=new CheckBox(this);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(e.done?GREEN:WHITE));cb.setChecked(e.done);cb.setContentDescription("完成 "+e.title);row.addView(cb,new LinearLayout.LayoutParams(dp(44),dp(48)));TextView tx=label(e.time+"  "+e.kind+(e.repeat.equals("none")?"":" ↻")+(ReminderPolicy.enabled(e,recurring)?" ◷":"")+"\n"+e.title,watch?16:17,e.done?GRAY:WHITE);tx.setPadding(0,dp(5),0,dp(5));if(e.done)tx.setPaintFlags(tx.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
            Runnable toggle=()->{store.toggle(e);update();};cb.setOnClickListener(v->toggle.run());tx.setOnClickListener(v->{if(watch)toggle.run();else edit(e);});if(!watch){row.setOnLongClickListener(v->{edit(e);return true;});
                if(!ReminderPolicy.shared(e)){String summary=!e.reminder?"关闭":Integer.bitCount(e.leads)==1?LeadTimes.label(LeadTimes.first(e.leads)).replace("准时提醒","准时"):Integer.bitCount(e.leads)+"次";
                    Button quick=button("提醒\n"+summary,()->editSingleReminder(e));quick.setTextSize(12);quick.setPadding(dp(2),0,dp(2),0);quick.setMinWidth(0);quick.setMinimumWidth(0);row.addView(quick,new LinearLayout.LayoutParams(dp(88),dp(56)));}
                else {TextView tag=label("统一\n提醒",11,GRAY);tag.setGravity(Gravity.CENTER);row.addView(tag,new LinearLayout.LayoutParams(dp(44),-2));}
            }}
        if(!watch&&detail)agenda.addView(button("＋ 添加任务 / 行程",()->edit(null)));agenda.addView(button("提醒权限 / 声音振动",()->reminderSettings()));agenda.addView(button("节日 API 更新 / 状态",()->holidaySettings()));if(!watch)agenda.addView(button("统一提醒设置",()->holidayReminderMenu()));if(detail)agenda.addView(button("返回月历",()->{detail=false;render();}));
    }
    void edit(Store.Entry occurrence){if(watch)return;final Store.Entry existing=occurrence==null?null:store.template(occurrence);if(occurrence!=null&&(existing==null||existing.deleted))return;
        ScrollView scroll=new ScrollView(this);LinearLayout panel=column();panel.setPadding(dp(20),dp(6),dp(20),dp(6));scroll.addView(panel);
        EditText title=new EditText(this);title.setHint("任务、行程或生日内容");title.setMaxLines(4);if(existing!=null)title.setText(existing.title);panel.addView(title);
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"任务","行程","生日","节日任务"}));type.setSelection(existing==null?0:existing.kind.equals("生日")?2:existing.kind.equals("行程")?1:existing.kind.equals("节日任务")?3:0);panel.addView(type);
        final LocalDate[] date={existing==null?selected:LocalDate.parse(existing.date)};final LocalTime[] time={existing==null?LocalTime.now().withSecond(0).withNano(0):LocalTime.parse(existing.time)};
        Button db=button(date[0].toString()+" · "+Holidays.lunarText(date[0],true),()->{}),tb=button(time[0].toString(),()->{});
        db.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("选择任务日期类型").setItems(new String[]{"公历日期","农历日期"},(dlg,which)->{java.util.function.Consumer<LocalDate> set=d->{date[0]=d;db.setText(d+" · "+Holidays.lunarText(d,true));};if(which==1){LunarPicker.show(this,date[0],set);}else{DatePickerDialog picker=new DatePickerDialog(this,(p,y,m,d)->set.accept(LocalDate.of(y,m+1,d)),date[0].getYear(),date[0].getMonthValue()-1,date[0].getDayOfMonth());picker.getDatePicker().setMinDate(LocalDate.of(1901,1,1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli());picker.getDatePicker().setMaxDate(LocalDate.of(2099,12,31).atTime(23,59).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());picker.show();}}).show());
        tb.setOnClickListener(v->new TimePickerDialog(this,(p,h,m)->{time[0]=LocalTime.of(h,m);tb.setText(time[0].toString());},time[0].getHour(),time[0].getMinute(),true).show());panel.addView(db);panel.addView(tb);
        panel.addView(label("循环重复",15,GREEN));Spinner repeat=new Spinner(this);repeat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Repeat.LABELS));repeat.setSelection(existing==null?0:Repeat.index(existing.repeat));panel.addView(repeat);
        TextView hint=label("可直接选择农历日期。每年农历重复按所选日期的农历月日。闰月仅在相同闰月出现时重复。缺少该日时使用当月最后一天。",12,GRAY);panel.addView(hint);
        CheckBox alert=new CheckBox(this);alert.setText("开启提醒（手机和手表）");alert.setChecked(existing==null||existing.reminder);panel.addView(alert);
        final int[] mask={existing==null?1:existing.leads};Button lead=leadButton(mask);panel.addView(lead);
        TextView sharedInfo=label("提前时间使用统一提醒设置",13,GRAY);panel.addView(sharedInfo);
        Runnable updateReminderUi=()->{Object kind=type.getSelectedItem();int ri=repeat.getSelectedItemPosition();boolean shared=ReminderPolicy.shared(kind==null?"任务":kind.toString(),Repeat.KEYS[Math.max(0,ri)]);lead.setVisibility(shared?View.GONE:View.VISIBLE);lead.setEnabled(alert.isChecked());sharedInfo.setVisibility(shared?View.VISIBLE:View.GONE);};
        alert.setOnCheckedChangeListener((v,checked)->updateReminderUi.run());
        repeat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){updateReminderUi.run();}});
        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){boolean initial=true;public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(initial){initial=false;}else if(pos==2){if(repeat.getSelectedItemPosition()==0)repeat.setSelection(4);alert.setChecked(true);}updateReminderUi.run();}});
        updateReminderUi.run();
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(existing==null?"添加任务 / 行程 / 生日 / 节日任务":"编辑任务（循环修改整个系列）").setView(scroll).setNegativeButton("取消",null).setPositiveButton("保存",null);
        if(existing!=null)b.setNeutralButton("删除",(d,w)->new AlertDialog.Builder(this).setMessage("删除此任务及全部循环日期？").setNegativeButton("取消",null).setPositiveButton("删除",(a,z)->{Store.Entry e=store.get(existing.id);if(e!=null){e.deleted=true;store.change(e);update();}}).show());
        AlertDialog dialog=b.create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(a->{String text=title.getText().toString().trim();if(text.isEmpty()){title.setError("请输入内容");return;}Store.Entry latest=existing==null?null:store.get(existing.id);if(latest!=null&&latest.deleted){dialog.dismiss();return;}
            Store.Entry e=new Store.Entry(existing==null?UUID.randomUUID().toString():existing.id,text,date[0].toString(),time[0].toString(),type.getSelectedItem().toString(),latest!=null&&latest.done,false,0,"");e.repeat=Repeat.KEYS[repeat.getSelectedItemPosition()];e.reminder=alert.isChecked();e.leads=LeadTimes.normalize(mask[0]);e.lead=LeadTimes.first(e.leads);if(!e.repeat.equals("none"))e.done=false;store.change(e);selected=occurrence!=null&&!e.repeat.equals("none")?LocalDate.parse(occurrence.date):date[0];month=YearMonth.from(selected);dialog.dismiss();update();refreshHolidays(false);if(ReminderPolicy.enabled(e,HolidayReminders.config(store,"RECURRING"))&&(!Reminders.allowed(this)||!Reminders.exact(this)))reminderSettings();}));dialog.show();}
    Button leadButton(int[] mask){
        Button b=button("提醒时间（可多选）\n"+LeadTimes.summary(mask[0]),()->{});
        b.setOnClickListener(v->{String[] names=new String[LeadTimes.MINUTES.length];boolean[] checks=new boolean[names.length];for(int i=0;i<names.length;i++){names[i]=LeadTimes.label(LeadTimes.MINUTES[i]);checks[i]=(mask[0]&(1<<i))!=0;}AlertDialog dlg=new AlertDialog.Builder(this).setTitle("提前提醒（可多选）").setMultiChoiceItems(names,checks,(d,i,checked)->checks[i]=checked).setNegativeButton("取消",null).setPositiveButton("确定",null).create();dlg.setOnShowListener(x->dlg.getButton(-1).setOnClickListener(a->{int value=0;for(int i=0;i<checks.length;i++)if(checks[i])value|=1<<i;if(value==0){Toast.makeText(this,"至少选择一个提醒时间",Toast.LENGTH_SHORT).show();return;}mask[0]=value;b.setText("提醒时间（可多选）\n"+LeadTimes.summary(value));dlg.dismiss();}));dlg.show();});return b;
    }
    void editSingleReminder(Store.Entry occurrence){
        Store.Entry entry=store.template(occurrence);if(entry==null||entry.deleted||ReminderPolicy.shared(entry))return;
        LinearLayout panel=column();panel.setPadding(dp(20),dp(10),dp(20),dp(10));
        CheckBox enabled=new CheckBox(this);enabled.setText("开启提醒");enabled.setChecked(entry.reminder);panel.addView(enabled);
        final int[] mask={entry.leads};Button lead=leadButton(mask);panel.addView(lead);lead.setEnabled(enabled.isChecked());enabled.setOnCheckedChangeListener((v,checked)->lead.setEnabled(checked));
        new AlertDialog.Builder(this).setTitle(entry.title+" · 提醒").setView(panel).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{Store.Entry latest=store.get(entry.id);if(latest==null||latest.deleted||ReminderPolicy.shared(latest))return;latest.reminder=enabled.isChecked();latest.leads=LeadTimes.normalize(mask[0]);latest.lead=LeadTimes.first(latest.leads);store.change(latest);update();if(latest.reminder&&!latest.done&&(!Reminders.allowed(this)||!Reminders.exact(this)))reminderSettings();}).show();
    }
    void holidayReminderMenu(){new AlertDialog.Builder(this).setTitle("统一提醒设置").setItems(new String[]{"中国节日 / 假期","阿根廷节日 / 假期","生日 / 循环任务 / 自建节日任务"},(d,i)->{if(i==2)editRecurringReminder();else editHolidayReminder(i==0?"CN":"AR");}).setNegativeButton("关闭",null).show();}
    void editRecurringReminder(){
        Store.Entry entry=HolidayReminders.config(store,"RECURRING");LinearLayout panel=column();panel.setPadding(dp(20),dp(10),dp(20),dp(10));
        CheckBox enabled=new CheckBox(this);enabled.setText("统一开启提醒");enabled.setChecked(HolidayReminders.enabled(entry));panel.addView(enabled);
        final int[] mask={entry.leads};Button lead=leadButton(mask);panel.addView(lead);lead.setEnabled(enabled.isChecked());enabled.setOnCheckedChangeListener((v,checked)->lead.setEnabled(checked));
        panel.addView(label("适用于所有生日、循环任务和自建节日任务，使用各任务自己的时刻。单个循环任务仍可关闭提醒。",13,GRAY));
        new AlertDialog.Builder(this).setTitle("生日 / 循环任务提醒").setView(panel).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{entry.reminder=enabled.isChecked();entry.deleted=false;entry.leads=LeadTimes.normalize(mask[0]);entry.lead=LeadTimes.first(entry.leads);store.change(entry);update();if(entry.reminder&&(!Reminders.allowed(this)||!Reminders.exact(this)))reminderSettings();}).show();
    }
    void editHolidayReminder(String country){
        Store.Entry entry=HolidayReminders.config(store,country);LinearLayout panel=column();panel.setPadding(dp(20),dp(10),dp(20),dp(10));
        CheckBox enabled=new CheckBox(this);enabled.setText("自动提醒该国所有日历节日 / 假期");enabled.setChecked(HolidayReminders.enabled(entry));panel.addView(enabled);
        final LocalTime[] time={LocalTime.parse(entry.time)};Button clock=button("提醒时刻 "+time[0],()->{});clock.setOnClickListener(v->new TimePickerDialog(this,(picker,h,m)->{time[0]=LocalTime.of(h,m);clock.setText("提醒时刻 "+time[0]);},time[0].getHour(),time[0].getMinute(),true).show());panel.addView(clock);
        final int[] mask={entry.leads};Button lead=leadButton(mask);panel.addView(lead);panel.addView(label("按日历所显示的每个节日日期提醒；连续假期每天分别提醒。手机和手表同步设置，各自通知。",13,GRAY));
        new AlertDialog.Builder(this).setTitle(country.equals("CN")?"中国节日提醒":"阿根廷节日提醒").setView(panel).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{entry.reminder=enabled.isChecked();entry.deleted=false;entry.time=time[0].toString();entry.leads=LeadTimes.normalize(mask[0]);entry.lead=LeadTimes.first(entry.leads);store.change(entry);refreshHolidays(false);if(entry.reminder&&(!Reminders.allowed(this)||!Reminders.exact(this)))reminderSettings();}).show();
    }
    class CalendarView extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); final RectF box=new RectF(); float left,top,cw,rh,header,bottom; final RectF headTap=new RectF(),footTap=new RectF(),todayTap=new RectF(),prevTap=new RectF(),nextTap=new RectF(); int rows; LocalDate start; float downX,downY; long downAt;
        final Typeface boldFace=Typeface.create("sans-serif-condensed",Typeface.BOLD);
        final Typeface lunarFace=Typeface.create("sans-serif",Typeface.BOLD);
        final Path triangle=new Path();
        final int touchSlop=ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
        final int minFling=ViewConfiguration.get(MainActivity.this).getScaledMinimumFlingVelocity();
        Bitmap currentPage, adjacentPage; YearMonth adjacentMonth; LocalDate adjacentDate; boolean dirty=true, dragging=false, settling=false, tracking=false, vertical=false;
        float slide=0; int pointer=-1; VelocityTracker velocity; ValueAnimator animation;
        LocalDate drawnToday;
        CalendarView(){super(MainActivity.this);setContentDescription("顶部回到今天，左右三角或滑动切换月份，点击首尾日期查看任务及节日，长按月历日期回到今天");setClickable(true);}
        void refreshPage(){dirty=true;invalidate();}
        void releaseVelocity(){if(velocity!=null){velocity.recycle();velocity=null;}}
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);if(animation!=null){animation.removeAllListeners();animation.cancel();animation=null;}releaseVelocity();tracking=dragging=settling=false;slide=0;currentPage=adjacentPage=null;adjacentMonth=null;dirty=true;}
        @Override protected void onDetachedFromWindow(){if(animation!=null){animation.removeAllListeners();animation.cancel();animation=null;}releaseVelocity();currentPage=adjacentPage=null;adjacentMonth=null;super.onDetachedFromWindow();}
        void layoutPage(YearMonth m){
            float w=getWidth(),h=getHeight();boolean round=watch&&getResources().getConfiguration().isScreenRound();
            start=m.atDay(1).minusDays(m.atDay(1).getDayOfWeek().getValue()%7);
            int offset=m.atDay(1).getDayOfWeek().getValue()%7;rows=(offset+m.lengthOfMonth()+6)/7;
            left=w*(round?.08f:.012f);cw=(w-2*left)/7;header=h*.145f;
            top=h*.295f;bottom=h*(round?.785f:.84f);rh=(bottom-top)/rows;
            todayTap.set(w*.30f,h*.033f,w*.70f,h*.103f);
            headTap.set(w*(round?.17f:.02f),h*.105f,w*(round?.83f:.98f),h*.196f);
            prevTap.set(w*(round?.07f:.02f),h*.197f,w*.29f,h*.255f);
            nextTap.set(w*.71f,h*.197f,w*(round?.93f:.98f),h*.255f);
            footTap.set(w*(round?.15f:.02f),h*(round?.804f:.855f),w*(round?.85f:.98f),h*(round?.94f:.99f));
        }
        Bitmap page(YearMonth m,LocalDate d,boolean hits){Bitmap b=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);canvas.drawColor(Color.BLACK);drawPage(canvas,m,d,hits);return b;}
        void ensureCurrent(){LocalDate now=LocalDate.now();if(currentPage==null||(!dragging&&!settling&&(dirty||!now.equals(drawnToday)))){currentPage=page(month,selected,true);drawnToday=now;dirty=false;adjacentPage=null;adjacentMonth=null;}}
        boolean allowedMonth(YearMonth m){return m.getYear()>=1901&&m.getYear()<=2099;}
        void ensureAdjacent(int delta){YearMonth m=month.plusMonths(delta);if(!allowedMonth(m))return;if(!m.equals(adjacentMonth)||adjacentPage==null){adjacentDate=selectionFor(m);adjacentPage=page(m,adjacentDate,false);adjacentMonth=m;layoutPage(month);}}
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(getWidth()<=0||getHeight()<=0)return;if(!watch){drawPage(c,month,selected,true);return;}ensureCurrent();c.drawBitmap(currentPage,slide,0,null);if(slide!=0&&adjacentPage!=null&&month.plusMonths(slide<0?1:-1).equals(adjacentMonth))c.drawBitmap(adjacentPage,slide+(slide<0?getWidth():-getWidth()),0,null);}
        void setSlide(float offset){int delta=offset<0?1:-1;YearMonth target=month.plusMonths(delta);if(!allowedMonth(target)){slide=Math.max(-getWidth()*.12f,Math.min(getWidth()*.12f,offset*.2f));}else{if(offset!=0)ensureAdjacent(delta);slide=Math.max(-getWidth(),Math.min(getWidth(),offset));}invalidate();}
        void settle(int delta){final int step=delta;float target=step==0?0:-step*getWidth();settling=true;dragging=false;animation=ValueAnimator.ofFloat(slide,target);animation.setDuration(step==0?140:180);animation.setInterpolator(new DecelerateInterpolator());animation.addUpdateListener(a->{slide=(Float)a.getAnimatedValue();invalidate();});animation.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator a){slide=0;settling=false;animation=null;if(step!=0){YearMonth target=month.plusMonths(step);LocalDate next=selectionFor(target);if(!dirty&&adjacentPage!=null&&target.equals(adjacentMonth)&&next.equals(adjacentDate)&&LocalDate.now().equals(drawnToday)){month=target;selected=next;currentPage=adjacentPage;adjacentPage=null;adjacentMonth=null;layoutPage(month);invalidate();refreshHolidays(false);}else move(step);}else invalidate();}});animation.start();}
        boolean watchTouch(MotionEvent e){int action=e.getActionMasked();switch(action){
            case MotionEvent.ACTION_DOWN:if(settling)return true;downX=e.getX();downY=e.getY();downAt=SystemClock.uptimeMillis();tracking=insideGrid(downX,downY)||controlAt(downX,downY)!=0;if(!tracking)return false;dragging=false;vertical=false;pointer=e.getPointerId(0);releaseVelocity();velocity=VelocityTracker.obtain();velocity.addMovement(e);ensureCurrent();return true;
            case MotionEvent.ACTION_MOVE:if(!tracking||settling)return true;int index=e.findPointerIndex(pointer);if(index<0)return true;velocity.addMovement(e);float dx=e.getX(index)-downX,dy=e.getY(index)-downY;if(!dragging&&!vertical&&Math.max(Math.abs(dx),Math.abs(dy))>touchSlop){if(Math.abs(dx)>Math.abs(dy))dragging=true;else vertical=true;}if(dragging)setSlide(dx);return true;
            case MotionEvent.ACTION_POINTER_DOWN:case MotionEvent.ACTION_POINTER_UP:if(tracking){tracking=false;releaseVelocity();if(dragging)settle(0);}return true;
            case MotionEvent.ACTION_UP:if(!tracking||settling)return true;tracking=false;float x=e.getX(),y=e.getY(),dxUp=x-downX,dyUp=y-downY;velocity.addMovement(e);velocity.computeCurrentVelocity(1000);float vx=velocity.getXVelocity(pointer);releaseVelocity();if(dragging){setSlide(dxUp);int step=dxUp<0?1:-1;boolean enough=Math.abs(dxUp)>=getWidth()*.12f||(Math.abs(dxUp)>touchSlop&&Math.abs(vx)>Math.max(minFling*3,dp(280))&&vx*dxUp>0);settle(enough&&allowedMonth(month.plusMonths(step))?step:0);return true;}if(vertical||Math.abs(dxUp)>touchSlop||Math.abs(dyUp)>touchSlop)return true;
                if(tapControl(x,y))return true;if(insideGrid(downX,downY)&&insideGrid(x,y)){if(SystemClock.uptimeMillis()-downAt>500){today();return true;}int col=Math.min(6,(int)((x-left)/cw)),row=Math.min(rows-1,(int)((y-top)/rh));select(start.plusDays(row*7L+col));performClick();}return true;
            case MotionEvent.ACTION_CANCEL:tracking=false;releaseVelocity();if(dragging&&!settling)settle(0);return true;default:return true;}}

        // Fit to actual glyph metrics, not an assumed number of Chinese characters.
        void fitted(Canvas c,String s,float x,float y,float size,int color,Typeface face,float maxWidth,float maxHeight,boolean emph){
            p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTypeface(face);p.setFakeBoldText(emph);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(size);
            float width=p.measureText(s),height=p.descent()-p.ascent();
            float factor=Math.min(1f,Math.min(maxWidth/Math.max(1,width),maxHeight/Math.max(1,height)));
            p.setTextSize(Math.max(1,size*factor));c.drawText(s,x,y-(p.ascent()+p.descent())/2,p);p.setFakeBoldText(false);
        }
        void coloredLine(Canvas c,String[] labels,int[] colors,float x,float y,float size,float max,float maxHeight){
            p.setTypeface(boldFace);p.setFakeBoldText(false);p.setTextSize(size);p.setTextAlign(Paint.Align.LEFT);p.setStyle(Paint.Style.FILL);
            float width=0;for(String label:labels)width+=p.measureText(label);
            float factor=Math.min(1f,Math.min(max/Math.max(1,width),maxHeight/Math.max(1,p.descent()-p.ascent())));
            p.setTextSize(Math.max(1,size*factor));width=0;for(String label:labels)width+=p.measureText(label);
            float left=x-width/2,base=y-(p.ascent()+p.descent())/2;
            for(int i=0;i<labels.length;i++){p.setColor(colors[i]);c.drawText(labels[i],left,base,p);left+=p.measureText(labels[i]);}
        }
        void arrow(Canvas c,RectF hit,boolean previous,boolean enabled){
            float x=hit.centerX(),y=hit.centerY(),halfW=hit.width()*.37f,halfH=hit.height()*.46f;
            triangle.reset();triangle.moveTo(x+(previous?-halfW:halfW),y);triangle.lineTo(x+(previous?halfW:-halfW),y-halfH);triangle.lineTo(x+(previous?halfW:-halfW),y+halfH);triangle.close();
            p.setStyle(Paint.Style.FILL);p.setColor(enabled?NAV_GREEN:0xff285436);c.drawPath(triangle,p);
        }
        void drawPage(Canvas c,YearMonth month,LocalDate selected,boolean hits){
            float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;float s=Math.min(w,h);boolean round=watch&&getResources().getConfiguration().isScreenRound();layoutPage(month);
            // Independent top button; the date/holiday strip opens the selected day's agenda.
            box.set(todayTap);box.inset(w*.025f,h*.006f);p.setStyle(Paint.Style.FILL);p.setColor(0xff07351c);c.drawRoundRect(box,h*.025f,h*.025f,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,s*.003f));p.setColor(NAV_GREEN);c.drawRoundRect(box,h*.025f,h*.025f,p);p.setStyle(Paint.Style.FILL);
            fitted(c,"回到今天",w/2,todayTap.centerY(),s*.043f,NAV_GREEN,lunarFace,w*.31f,h*.055f,true);
            String cn=Holidays.china(selected),ar=Holidays.argentina(selected);float headWidth=w*(round?.65f:.96f);
            coloredLine(c,new String[]{selected.toString()+"  ",fullLunar(selected)},new int[]{WHITE,LUNAR_GOLD},w/2,cn.isEmpty()?h*.15f:h*.128f,s*.047f,headWidth,h*.058f);
            if(!cn.isEmpty())fitted(c,"中国 · "+cn,w/2,h*.174f,s*.043f,RED,lunarFace,headWidth,h*.043f,true);
            float barY=h*.226f;
            box.set(w*(round?.105f:.025f),h*.198f,w*(round?.895f:.975f),h*.254f);
            p.setStyle(Paint.Style.STROKE);p.setColor(0xff159849);p.setStrokeWidth(Math.max(1,s*.003f));c.drawRoundRect(box,h*.028f,h*.028f,p);p.setStyle(Paint.Style.FILL);
            fitted(c,month.getYear()+"年 "+month.getMonthValue()+"月",w/2,barY,s*.052f,WHITE,boldFace,w*.42f,h*.055f,false);
            arrow(c,prevTap,true,allowedMonth(month.minusMonths(1)));arrow(c,nextTap,false,allowedMonth(month.plusMonths(1)));
            box.set(left,h*.257f,w-left,h*.292f);p.setColor(0xff062c19);c.drawRoundRect(box,h*.012f,h*.012f,p);
            String[] week={"日","一","二","三","四","五","六"};
            for(int j=0;j<7;j++)fitted(c,week[j],left+(j+.5f)*cw,h*.2745f,s*.036f,j==0||j==6?RED:WHITE,lunarFace,cw*.9f,h*.034f,false);
            Map<String,Integer> status=new HashMap<>();List<Store.Entry> snapshot=store.all();LocalDate now=LocalDate.now();
            for(int i=0;i<rows*7;i++){LocalDate day=start.plusDays(i);for(Store.Entry e:store.day(day,snapshot)){int prev=status.getOrDefault(e.date,0);status.put(e.date,e.done?Math.max(prev,1):2);}}
            for(int i=0;i<rows*7;i++){
                LocalDate d=start.plusDays(i);int col=i%7,row=i/7;float x=left+col*cw,y=top+row*rh;boolean same=YearMonth.from(d).equals(month);
                String ch=Holidays.china(d),arg=Holidays.argentina(d);int color=!same?0xff656565:!ch.isEmpty()&&!arg.isEmpty()?PURPLE:!ch.isEmpty()?RED:!arg.isEmpty()?BLUE:col==0||col==6?RED:WHITE;
                boolean isToday=d.equals(now),isSelected=d.equals(selected);
                if(isToday||isSelected){box.set(x+1,y+1,x+cw-1,y+rh-1);p.setStyle(Paint.Style.FILL);p.setColor(isToday?0xff123d22:0xff142a1b);c.drawRoundRect(box,cw*.13f,cw*.13f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,s*(isToday?.005f:.003f)));p.setColor(isToday?NAV_GREEN:0xff549e66);c.drawRoundRect(box,cw*.13f,cw*.13f,p);p.setStyle(Paint.Style.FILL);}
                // Keep the large original number scale where row height permits; lunar uses a separate full-width line.
                float number=Math.min(cw*.72f,rh*.70f);
                fitted(c,""+d.getDayOfMonth(),x+cw*.5f,y+rh*.32f,number,color,boldFace,cw*.91f,rh*.62f,false);
                String lunar=fullLunar(d);float ls=Math.min(cw*.33f,rh*.32f);
                fitted(c,lunar,x+cw*.5f,y+rh*.755f,ls,same?LUNAR_GOLD:LUNAR_DIM,lunarFace,cw*.94f,rh*.32f,true);
                int st=status.getOrDefault(d.toString(),0);if(st>0){p.setColor(st==2?YELLOW:GREEN);p.setStyle(Paint.Style.FILL);float dot=Math.max(1,Math.min(cw,rh)*.042f);c.drawCircle(x+cw*.5f,y+rh*.94f,dot,p);}
            }
            // Separate Argentina strip; no holiday name is printed on ordinary dates.
            float fy=round?h*.861f:footTap.centerY(),fw=w*(round?.49f:.95f);
            box.set(footTap);if(round){box.left=w*.24f;box.right=w*.76f;box.bottom=h*.918f;}else box.inset(w*.025f,h*.005f);p.setStyle(Paint.Style.FILL);p.setColor(0xff062519);c.drawRoundRect(box,h*.026f,h*.026f,p);p.setStyle(Paint.Style.STROKE);p.setColor(0xff159849);p.setStrokeWidth(Math.max(1,s*.003f));c.drawRoundRect(box,h*.026f,h*.026f,p);p.setStyle(Paint.Style.FILL);
            if(ar.isEmpty())coloredLine(c,new String[]{"阿根廷  ",selected.toString()},new int[]{NAV_GREEN,WHITE},w/2,fy,s*.045f,fw,h*.06f);
            else{coloredLine(c,new String[]{"阿根廷  ",selected.toString()},new int[]{NAV_GREEN,WHITE},w/2,fy-h*.025f,s*.043f,fw,h*.05f);fitted(c,ar,w/2,fy+h*.023f,s*.046f,NAV_GREEN,lunarFace,fw,h*.047f,true);}
        }
        int controlAt(float x,float y){if(todayTap.contains(x,y))return 1;if(headTap.contains(x,y))return 2;if(prevTap.contains(x,y))return 3;if(nextTap.contains(x,y))return 4;if(footTap.contains(x,y))return 5;return 0;}
        boolean tapControl(float x,float y){int target=controlAt(downX,downY);if(target==0||target!=controlAt(x,y))return false;
            if(target==1)today();else if(target==2||target==5)openSelected();else{int delta=target==3?-1:1;if(allowedMonth(month.plusMonths(delta))){if(watch){ensureAdjacent(delta);settle(delta);}else move(delta);}}performClick();return true;
        }
        boolean insideGrid(float x,float y){return start!=null&&y>=top&&y<bottom&&x>=left&&x<left+7*cw;}
        @Override public boolean onTouchEvent(MotionEvent e){if(watch)return watchTouch(e);switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:downX=e.getX();downY=e.getY();downAt=SystemClock.uptimeMillis();return insideGrid(downX,downY)||controlAt(downX,downY)!=0;
            case MotionEvent.ACTION_UP:float x=e.getX(),y=e.getY(),dx=x-downX,dy=y-downY;
                if(controlAt(downX,downY)!=0){if(Math.abs(dx)<dp(16)&&Math.abs(dy)<dp(16))tapControl(x,y);return true;}
                if(!insideGrid(downX,downY))return false;
                if(Math.abs(dx)>getWidth()*.14f&&Math.abs(dx)>Math.abs(dy)){move(dx<0?1:-1);return true;}
                if(!insideGrid(x,y)||Math.abs(dx)>cw*.5f||Math.abs(dy)>rh*.5f)return true;
                if(SystemClock.uptimeMillis()-downAt>500){today();return true;}
                int col=Math.min(6,(int)((x-left)/cw)),row=Math.min(rows-1,(int)((y-top)/rh));select(start.plusDays(row*7L+col));performClick();return true;
            case MotionEvent.ACTION_CANCEL:return true;default:return true;}}
        @Override public boolean performClick(){super.performClick();return true;}
    }
}
